/* @ds-bundle: {"format":4,"namespace":"IvoryMediaDesignSystem_8a5500","components":[{"name":"Card","sourcePath":"components/cards/Card.jsx"},{"name":"QuoteBlock","sourcePath":"components/cards/QuoteBlock.jsx"},{"name":"ClipText","sourcePath":"components/cards/QuoteBlock.jsx"},{"name":"StatBlock","sourcePath":"components/cards/StatBlock.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"}],"sourceHashes":{"components/cards/Card.jsx":"dde5d04445a4","components/cards/QuoteBlock.jsx":"a6d762f175d7","components/cards/StatBlock.jsx":"df284e2319d8","components/core/Button.jsx":"cf06ffdd0024","components/core/Chip.jsx":"967e33c7e180","components/core/Eyebrow.jsx":"89f17837a667","components/core/Logo.jsx":"512851e63e2a","ui_kits/website/Sections.jsx":"57cc8f9a165e"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.IvoryMediaDesignSystem_8a5500 = window.IvoryMediaDesignSystem_8a5500 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/cards/QuoteBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Testimonial quote block — use only if the quote carries a specific outcome.
 * Five green stars, Host Grotesk medium quote, avatar + attribution.
 * Wrap the payoff phrase in <span data-clip> to apply the text-clip gradient.
 */
function QuoteBlock({
  quote,
  name,
  detail,
  stars = 5,
  avatar,
  style = {},
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--im-ivory)',
      border: '1px solid var(--im-border)',
      borderRadius: 'var(--im-radius-lg)',
      padding: 32,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--im-green-mid)',
      fontSize: 22,
      letterSpacing: 4
    }
  }, '★'.repeat(stars)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--im-font-head)',
      fontWeight: 500,
      fontSize: 24,
      letterSpacing: '-0.02em',
      lineHeight: 1.3,
      marginTop: 18,
      color: 'var(--im-ink)'
    }
  }, children || quote), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: '50%',
      background: avatar ? `center/cover url(${avatar})` : 'var(--im-photo)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--im-font-head)',
      fontWeight: 600,
      fontSize: 16,
      color: 'var(--im-ink)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--im-font-body)',
      fontSize: 14,
      color: 'var(--im-slate)'
    }
  }, detail))));
}

/** Helper span with the signature text-clip gradient for the payoff phrase. */
function ClipText({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--im-grad-text)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent'
    }
  }, children);
}
Object.assign(__ds_scope, { QuoteBlock, ClipText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/QuoteBlock.jsx", error: String((e && e.message) || e) }); }

// components/cards/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Big-number stat block — measured in results, not likes.
 * bone / dark / gradient (with hatch). Number in Host Grotesk 700.
 */
function StatBlock({
  value,
  label,
  surface = 'bone',
  style = {},
  ...rest
}) {
  const surfaces = {
    bone: {
      background: 'var(--im-bone)',
      num: 'var(--im-ink)',
      lbl: 'var(--im-slate)'
    },
    dark: {
      background: 'var(--im-black)',
      num: 'var(--im-ivory)',
      lbl: 'rgba(244,243,239,0.6)'
    },
    gradient: {
      background: 'var(--im-grad-panel)',
      num: 'var(--im-black)',
      lbl: 'rgba(14,18,22,0.65)'
    }
  };
  const s = surfaces[surface] || surfaces.bone;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 'var(--im-radius-lg)',
      padding: 28,
      background: s.background,
      ...style
    }
  }, rest), surface === 'gradient' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--im-hatch)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--im-font-head)',
      fontWeight: 700,
      fontSize: 56,
      letterSpacing: '-0.03em',
      lineHeight: 1,
      color: s.num
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--im-font-mono)',
      fontSize: 12,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: s.lbl,
      marginTop: 8
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Ivory Media button. Primary is the gradient CTA — one per section.
 * Near-black text sits on the Kelly-green gradient (80/20 rule).
 */
function Button({
  children,
  variant = 'primary',
  pill = false,
  size = 'md',
  disabled = false,
  href,
  onClick,
  style = {},
  ...rest
}) {
  const pad = size === 'lg' ? '16px 32px' : size === 'sm' ? '10px 18px' : '14px 26px';
  const fs = size === 'lg' ? 16 : size === 'sm' ? 13 : 15;
  const base = {
    fontFamily: 'var(--im-font-head)',
    fontWeight: 600,
    fontSize: fs,
    lineHeight: 1,
    border: 0,
    padding: pad,
    borderRadius: pill ? 'var(--im-radius-pill)' : 'var(--im-radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    textDecoration: 'none',
    transition: 'transform .15s ease, filter .15s ease, box-shadow .15s ease, background .15s ease, color .15s ease',
    opacity: disabled ? 0.45 : 1,
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--im-grad-button)',
      color: 'var(--im-on-accent)'
    },
    solid: {
      background: 'var(--im-ink)',
      color: 'var(--im-ivory)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--im-ink)',
      border: '1px solid rgba(20,20,20,0.28)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--im-accent-text)',
      padding: `${pad.split(' ')[0]} 0`
    }
  };
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    onClick: disabled ? undefined : onClick,
    disabled: Tag === 'button' ? disabled : undefined,
    style: {
      ...base,
      ...(variants[variant] || variants.primary),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Category chip / tag. Dark chip with green text is the default.
 * Gradient chip flags the hero label only — ration it.
 */
function Chip({
  children,
  variant = 'dark',
  style = {},
  ...rest
}) {
  const variants = {
    dark: {
      background: 'var(--im-black)',
      color: 'var(--im-green-light)'
    },
    gradient: {
      background: 'var(--im-grad-button)',
      color: 'var(--im-on-accent)'
    },
    bone: {
      background: 'var(--im-bone)',
      color: 'var(--im-ink)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--im-accent-text)',
      boxShadow: 'inset 0 0 0 1px rgba(35,120,24,0.4)'
    },
    meta: {
      background: 'var(--im-panel)',
      color: 'var(--im-slate)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: 'var(--im-font-mono)',
      fontSize: 12,
      fontWeight: 500,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      padding: '9px 16px',
      borderRadius: 'var(--im-radius-pill)',
      display: 'inline-block',
      ...(variants[variant] || variants.dark),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Uppercase JetBrains Mono meta label — the system's connective tissue.
 * Used for eyebrows, indices, URLs and section markers.
 */
function Eyebrow({
  children,
  color = 'green',
  tracking = '0.16em',
  style = {},
  ...rest
}) {
  const colors = {
    green: 'var(--im-accent-text)',
    slate: 'var(--im-slate)',
    ink: 'var(--im-ink)',
    light: 'var(--im-green-light)',
    invert: 'rgba(244,243,239,0.6)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      fontFamily: 'var(--im-font-mono)',
      fontSize: 11,
      fontWeight: 500,
      letterSpacing: tracking,
      textTransform: 'uppercase',
      color: colors[color] || color,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/cards/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Content card. Light (default), warm bone, or dark surface.
 * Dark surface carries a faint corner watermark of the mark.
 * Radius 18px. One green moment per view — keep the accent to the eyebrow/link.
 */
function Card({
  surface = 'light',
  eyebrow,
  title,
  body,
  link,
  watermark = true,
  assetBase = '',
  children,
  style = {},
  ...rest
}) {
  const dark = surface === 'dark';
  const surfaces = {
    light: {
      background: 'var(--im-ivory)',
      border: '1px solid var(--im-border)',
      color: 'var(--im-ink)'
    },
    bone: {
      background: 'var(--im-bone)',
      color: 'var(--im-ink)'
    },
    dark: {
      background: 'var(--im-black)',
      color: 'var(--im-ivory)'
    }
  };
  const markSrc = (assetBase ? assetBase.replace(/\/$/, '') + '/' : '') + 'assets/im-mark-ivory.png';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 'var(--im-radius-lg)',
      padding: 26,
      ...(surfaces[surface] || surfaces.light),
      ...style
    }
  }, rest), dark && watermark && /*#__PURE__*/React.createElement("img", {
    src: markSrc,
    alt: "",
    style: {
      position: 'absolute',
      right: -40,
      bottom: -30,
      width: 180,
      opacity: 0.08
    }
  }), eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    color: dark ? 'light' : 'green'
  }, eyebrow)), title && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--im-font-head)',
      fontWeight: 700,
      fontSize: 26,
      letterSpacing: '-0.025em',
      lineHeight: 1.05,
      marginTop: eyebrow ? 12 : 0
    }
  }, title), body && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--im-font-body)',
      fontSize: 14,
      lineHeight: 1.55,
      color: dark ? 'rgba(244,243,239,0.6)' : 'var(--im-slate)',
      marginTop: 10
    }
  }, body), link && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--im-font-head)',
      fontWeight: 600,
      fontSize: 14,
      color: dark ? 'var(--im-green-light)' : 'var(--im-accent-text)',
      marginTop: 16
    }
  }, link, " \u2192"), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SRC = {
  'logo-black': 'assets/im-logo-black.png',
  'logo-ivory': 'assets/im-logo-ivory.png',
  'mark-black': 'assets/im-mark-black.png',
  'mark-ivory': 'assets/im-mark-ivory.png'
};

/**
 * Ivory Media logo / mark. Never recolour or stretch.
 * Ivory on dark, black on light or green.
 * As a watermark: 7–12% opacity, bleeding off a corner.
 */
function Logo({
  kind = 'logo',
  tone = 'black',
  height = 30,
  assetBase = '',
  style = {},
  ...rest
}) {
  const key = `${kind}-${tone}`;
  const src = (assetBase ? assetBase.replace(/\/$/, '') + '/' : '') + SRC[key];
  return /*#__PURE__*/React.createElement("img", _extends({
    src: src,
    alt: kind === 'logo' ? 'Ivory Media' : '',
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Sections.jsx
try { (() => {
/* Ivory Media — marketing website sections.
   Ports the canonical site recreation into reusable section components.
   Uses the design-system bundle for primitives; exports sections to window. */
const {
  Eyebrow,
  Chip,
  Button,
  Logo,
  StatBlock,
  QuoteBlock,
  ClipText,
  Card
} = window.IvoryMediaDesignSystem_8a5500;
const A = '../..'; // asset base -> project root

const mono = "'JetBrains Mono',monospace";
const head = "'Host Grotesk',system-ui,sans-serif";
function Nav() {
  const link = {
    cursor: 'pointer'
  };
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Nav",
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 20,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px 40px',
      background: 'rgba(244,243,239,0.92)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid rgba(20,20,20,0.08)'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    kind: "logo",
    tone: "black",
    height: 28,
    assetBase: A
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      fontSize: 13,
      fontWeight: 500,
      color: 'rgba(20,20,20,0.72)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Services"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Industries"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Work"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "About"), /*#__PURE__*/React.createElement("span", {
    style: link
  }, "Insights"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    pill: true,
    size: "sm"
  }, "Start a project")));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Hero",
    style: {
      padding: '64px 40px 52px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: mono,
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: '0.16em',
      color: '#237818'
    }
  }, "\u2605\u2605\u2605\u2605\u2605 \xA05.0 ON GOOGLE \xB7 60+ REVIEWS"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 68,
      letterSpacing: '-0.04em',
      lineHeight: 0.96,
      marginTop: 20,
      maxWidth: 900
    }
  }, "Bringing the magic to your ", /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'linear-gradient(120deg,#6FCF4E 0%,#3DA82F 62%,#237818 100%)',
      padding: '0 8px',
      borderRadius: 6,
      color: '#0E1216'
    }
  }, "brand.")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 19,
      lineHeight: 1.6,
      color: 'rgba(20,20,20,0.62)',
      marginTop: 22,
      maxWidth: 520
    }
  }, "We create story-led video and digital content for the industries that grow and build Australia \u2014 agriculture, manufacturing and education."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 30
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "solid"
  }, "Start a project"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "See our work")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 36,
      height: 440,
      borderRadius: 18,
      position: 'relative',
      overflow: 'hidden',
      background: 'linear-gradient(155deg,#6FCF4E 0%,#3DA82F 62%,#237818 100%)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'repeating-linear-gradient(45deg,rgba(14,18,22,0.05) 0 1px,transparent 1px 14px)'
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: `${A}/assets/im-mark-black.png`,
    style: {
      position: 'absolute',
      right: -40,
      bottom: -40,
      width: 440,
      opacity: 0.12
    },
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: 18,
      left: 18,
      fontFamily: mono,
      fontSize: 11,
      color: 'rgba(14,18,22,0.65)'
    }
  }, "SHOWREEL / HERO FILM 16:9"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%,-50%)',
      width: 74,
      height: 74,
      borderRadius: '50%',
      background: '#0E1216',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 0,
      height: 0,
      borderLeft: '18px solid #6FCF4E',
      borderTop: '11px solid transparent',
      borderBottom: '11px solid transparent',
      marginLeft: 4
    }
  }))));
}
function Brands() {
  const bar = {
    flex: 1,
    height: 28,
    borderRadius: 6,
    background: 'rgba(20,20,20,0.07)'
  };
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Brands",
    style: {
      padding: '22px 40px',
      borderTop: '1px solid rgba(20,20,20,0.08)',
      borderBottom: '1px solid rgba(20,20,20,0.08)',
      display: 'flex',
      alignItems: 'center',
      gap: 26
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: mono,
      fontSize: 10,
      letterSpacing: '0.14em',
      color: 'rgba(20,20,20,0.45)',
      whiteSpace: 'nowrap'
    }
  }, "BRANDS WE'VE LOVED WORKING WITH"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flex: 1
    }
  }, [0, 1, 2, 3, 4, 5].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: bar
  }))));
}
const services = [{
  n: '01',
  t: 'Video production',
  d: 'Story-led films, reels and brand shoots.',
  s: 'bone'
}, {
  n: '02',
  t: 'Social & content',
  d: 'Organic strategy, scripting and posting.',
  s: 'dark'
}, {
  n: '03',
  t: 'Paid media',
  d: 'Meta & Google ads that convert and drive growth.',
  s: 'green'
}, {
  n: '04',
  t: 'Web & design',
  d: 'Sites, branding and campaign design.',
  s: 'bone'
}];
function Services() {
  const card = {
    flex: 1,
    borderRadius: 16,
    padding: 26,
    minHeight: 210,
    display: 'flex',
    flexDirection: 'column'
  };
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Services",
    style: {
      padding: '56px 40px 48px',
      backgroundImage: 'radial-gradient(rgba(20,20,20,0.06) 1px,transparent 1.5px)',
      backgroundSize: '20px 20px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "What we do best"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em'
    }
  }, "One team, every platform"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'rgba(20,20,20,0.55)',
      maxWidth: 320,
      textAlign: 'right'
    }
  }, "From the first idea to the final post \u2014 production, content and media under one roof.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginTop: 26
    }
  }, services.map(sv => {
    if (sv.s === 'dark') return /*#__PURE__*/React.createElement("div", {
      key: sv.n,
      style: {
        ...card,
        background: '#0E1216',
        color: '#F4F3EF'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: mono,
        fontSize: 11,
        color: '#6FCF4E'
      }
    }, sv.n), /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 22,
        letterSpacing: '-0.02em',
        marginTop: 'auto'
      }
    }, sv.t), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        lineHeight: 1.5,
        color: 'rgba(244,243,239,0.6)',
        marginTop: 8
      }
    }, sv.d));
    if (sv.s === 'green') return /*#__PURE__*/React.createElement("div", {
      key: sv.n,
      style: {
        ...card,
        position: 'relative',
        overflow: 'hidden',
        background: 'linear-gradient(150deg,#6FCF4E,#3DA82F 60%,#237818)',
        color: '#0E1216'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'repeating-linear-gradient(45deg,rgba(14,18,22,0.055) 0 1px,transparent 1px 12px)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: mono,
        fontSize: 11,
        color: 'rgba(14,18,22,0.65)',
        position: 'relative'
      }
    }, sv.n), /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 22,
        letterSpacing: '-0.02em',
        marginTop: 'auto',
        position: 'relative'
      }
    }, sv.t), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        lineHeight: 1.5,
        color: 'rgba(14,18,22,0.7)',
        marginTop: 8,
        position: 'relative'
      }
    }, sv.d));
    return /*#__PURE__*/React.createElement("div", {
      key: sv.n,
      style: {
        ...card,
        background: '#E6E3D9'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: mono,
        fontSize: 11,
        color: '#78766E'
      }
    }, sv.n), /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 22,
        letterSpacing: '-0.02em',
        marginTop: 'auto'
      }
    }, sv.t), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        lineHeight: 1.5,
        color: 'rgba(20,20,20,0.6)',
        marginTop: 8
      }
    }, sv.d));
  })));
}
const industries = ['Agriculture', 'Manufacturing', 'Education', 'Industrial', 'Corporate', 'Medical & health'];
function Industries() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Industries",
    style: {
      padding: '56px 40px 48px',
      background: '#0E1216',
      color: '#F4F3EF'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 11,
      letterSpacing: '0.16em',
      background: 'linear-gradient(90deg,#6FCF4E,#55BC3E)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent',
      width: 'fit-content'
    }
  }, "INDUSTRIES WE GROW"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em',
      marginTop: 10,
      maxWidth: 620
    }
  }, "Built for the businesses that make Australia run"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 14,
      marginTop: 28
    }
  }, industries.map((name, i) => /*#__PURE__*/React.createElement("div", {
    key: name,
    style: {
      background: '#171C21',
      border: '1px solid rgba(244,243,239,0.08)',
      borderRadius: 14,
      padding: 22,
      minHeight: 120,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: mono,
      fontSize: 11,
      color: '#6FCF4E'
    }
  }, String(i + 1).padStart(2, '0')), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 20,
      letterSpacing: '-0.02em'
    }
  }, name)))));
}
const whyus = [{
  t: 'Industry insiders',
  d: 'We speak your language, on the floor and in the field.'
}, {
  t: 'One accountable team',
  d: 'Strategy to delivery, no hand-offs, no gaps.'
}, {
  t: 'Results, not vanity',
  d: 'Measured in leads and revenue, not likes.'
}, {
  t: 'Genuinely easy',
  d: 'A few hours a month from you — we handle the rest.'
}];
function WhyUs() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Why us",
    style: {
      padding: '56px 40px 48px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Designed for your success"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em',
      marginTop: 10,
      maxWidth: 640
    }
  }, "Experience a creative agency that actually gets it"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginTop: 28
    }
  }, whyus.map(w => /*#__PURE__*/React.createElement("div", {
    key: w.t,
    style: {
      flex: 1,
      border: '1px solid rgba(20,20,20,0.12)',
      borderRadius: 14,
      padding: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 9,
      background: 'linear-gradient(135deg,#6FCF4E,#3DA82F)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 17,
      letterSpacing: '-0.01em',
      marginTop: 16
    }
  }, w.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      lineHeight: 1.5,
      color: 'rgba(20,20,20,0.6)',
      marginTop: 6
    }
  }, w.d)))));
}
const work = [{
  cat: 'AGRICULTURE',
  t: 'Family farm lifts direct sales 30% YoY on organic video.'
}, {
  cat: 'MANUFACTURING',
  t: 'Industrial supplier: 476 leads in 8 weeks at $6.65 CPL.'
}, {
  cat: 'EDUCATION',
  t: 'Training college fills courses with a year-round engine.'
}];
function Work() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Work",
    style: {
      padding: '56px 40px 48px',
      background: '#EFEEE8',
      borderTop: '1px solid rgba(20,20,20,0.08)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Our work in action"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em',
      marginTop: 10
    }
  }, "Real results, real businesses")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    pill: true,
    size: "sm"
  }, "View all work")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      marginTop: 26
    }
  }, work.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.cat,
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 210,
      borderRadius: 14,
      background: 'repeating-linear-gradient(45deg,#E6E3D9 0 14px,#DDD9CD 14px 28px)',
      display: 'flex',
      alignItems: 'flex-end',
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: mono,
      fontSize: 10,
      color: '#78766E'
    }
  }, "CASE IMAGE")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 10,
      color: '#237818',
      marginTop: 12
    }
  }, c.cat), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 18,
      letterSpacing: '-0.02em',
      marginTop: 6,
      lineHeight: 1.2
    }
  }, c.t)))));
}
const steps = [{
  n: '01',
  t: 'Discover',
  d: 'We learn your business, market and goals.',
  c: '#6FCF4E'
}, {
  n: '02',
  t: 'Strategise',
  d: 'A clear plan for content and channels.',
  c: '#55BC3E'
}, {
  n: '03',
  t: 'Create',
  d: 'We film, edit and produce the content.',
  c: '#3DA82F'
}, {
  n: '04',
  t: 'Grow',
  d: 'We distribute, optimise and scale results.',
  c: '#237818'
}];
function Process() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Process",
    style: {
      padding: '56px 40px 48px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "The method behind the magic"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em',
      marginTop: 10
    }
  }, "How we work"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginTop: 26
    }
  }, steps.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: {
      flex: 1,
      borderTop: `2px solid ${s.c}`,
      paddingTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 12,
      color: '#237818'
    }
  }, "STEP ", s.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 20,
      letterSpacing: '-0.02em',
      marginTop: 8
    }
  }, s.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      lineHeight: 1.55,
      color: 'rgba(20,20,20,0.6)',
      marginTop: 8
    }
  }, s.d)))));
}
function StatsBand() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Stats",
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'linear-gradient(120deg,#6FCF4E 0%,#3DA82F 60%,#237818 100%)',
      color: '#0E1216',
      padding: '44px 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'repeating-linear-gradient(45deg,rgba(14,18,22,0.055) 0 1px,transparent 1px 13px)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 26,
      letterSpacing: '-0.02em',
      maxWidth: 250,
      lineHeight: 1.1
    }
  }, "Measured in results, not likes."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 48
    }
  }, [['476', 'LEADS IN 8 WEEKS'], ['30%', 'YOY GROWTH'], ['60+', '5-STAR REVIEWS']].map(([v, l]) => /*#__PURE__*/React.createElement("div", {
    key: l
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 46,
      letterSpacing: '-0.03em'
    }
  }, v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 11,
      color: 'rgba(14,18,22,0.65)',
      marginTop: 2
    }
  }, l))))));
}
const quotes = [{
  q: 'They understood our industry from day one — the content finally sounds like us.',
  n: 'Operations Director',
  d: 'Manufacturing group'
}, {
  q: "The leads haven't stopped since we started. Genuinely easy to work with.",
  n: 'Founder',
  d: 'Agribusiness'
}, {
  q: 'Professional, creative and fast. The quality is faultless every time.',
  n: 'Marketing Lead',
  d: 'Education provider'
}];
function Testimonials() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Testimonials",
    style: {
      padding: '56px 40px 48px',
      background: '#EFEEE8'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Why our clients trust us"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      marginTop: 22
    }
  }, quotes.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.n,
    style: {
      flex: 1,
      background: '#F4F3EF',
      border: '1px solid rgba(20,20,20,0.1)',
      borderRadius: 16,
      padding: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#237818',
      fontSize: 14
    }
  }, "\u2605\u2605\u2605\u2605\u2605"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      lineHeight: 1.5,
      marginTop: 14
    }
  }, "\"", c.q, "\""), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: '50%',
      background: '#DDD9CD'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 13
    }
  }, c.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'rgba(20,20,20,0.55)'
    }
  }, c.d)))))));
}
const posts = [{
  r: '6 MIN READ',
  t: 'Why video is the fastest trust-builder for industrial brands.'
}, {
  r: '8 MIN READ',
  t: 'The content system that turns attention into booked clients.'
}, {
  r: '5 MIN READ',
  t: 'Filming on-site: a simple guide for busy operators.'
}];
function Insights() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Insights",
    style: {
      padding: '56px 40px 48px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Insights & inspiration"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em',
      marginTop: 10
    }
  }, "From the studio")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    pill: true,
    size: "sm"
  }, "View all")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      marginTop: 26
    }
  }, posts.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.t,
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 160,
      borderRadius: 14,
      background: 'repeating-linear-gradient(45deg,#E6E3D9 0 14px,#DDD9CD 14px 28px)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 10,
      color: 'rgba(20,20,20,0.5)',
      marginTop: 12
    }
  }, p.r), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 17,
      letterSpacing: '-0.02em',
      marginTop: 6,
      lineHeight: 1.25
    }
  }, p.t)))));
}
const faqs = ['Who do you work with?', "What's included in a content package?", 'How quickly will I see results?', 'Do you only work in Australia?'];
function FAQ() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "FAQ",
    style: {
      padding: '56px 40px 48px',
      background: '#EFEEE8'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 38,
      letterSpacing: '-0.03em'
    }
  }, "Frequently asked questions"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      maxWidth: 820
    }
  }, faqs.map(q => /*#__PURE__*/React.createElement("div", {
    key: q,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 0',
      borderBottom: '1px solid rgba(20,20,20,0.12)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 18,
      letterSpacing: '-0.01em'
    }
  }, q), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      color: '#237818'
    }
  }, "+")))));
}
function Footer() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Footer",
    style: {
      background: '#0E1216',
      color: '#F4F3EF',
      padding: '64px 40px 40px',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `${A}/assets/im-mark-ivory.png`,
    style: {
      position: 'absolute',
      right: -80,
      top: -30,
      width: 400,
      opacity: 0.08
    },
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    color: "light"
  }, "Ready to unleash the magic?"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 48,
      letterSpacing: '-0.035em',
      lineHeight: 1.0,
      marginTop: 14,
      maxWidth: 520
    }
  }, "Let's make something worth watching.")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, "Start a project")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      marginTop: 56,
      paddingTop: 24,
      borderTop: '1px solid rgba(244,243,239,0.12)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Logo, {
    kind: "logo",
    tone: "ivory",
    height: 44,
    assetBase: A,
    style: {
      opacity: 0.9
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'rgba(244,243,239,0.5)',
      marginTop: 14,
      maxWidth: 280,
      lineHeight: 1.5
    }
  }, "Story-led video and digital content for agriculture, manufacturing and education.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 56,
      fontSize: 13,
      color: 'rgba(244,243,239,0.7)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: mono,
      fontSize: 10,
      color: 'rgba(244,243,239,0.4)'
    }
  }, "COMPANY"), /*#__PURE__*/React.createElement("span", null, "Services"), /*#__PURE__*/React.createElement("span", null, "Industries"), /*#__PURE__*/React.createElement("span", null, "Work"), /*#__PURE__*/React.createElement("span", null, "About")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: mono,
      fontSize: 10,
      color: 'rgba(244,243,239,0.4)'
    }
  }, "CONNECT"), /*#__PURE__*/React.createElement("span", null, "Instagram"), /*#__PURE__*/React.createElement("span", null, "LinkedIn"), /*#__PURE__*/React.createElement("span", null, "YouTube"), /*#__PURE__*/React.createElement("span", null, "hello@ivorymedia.com.au")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: mono,
      fontSize: 11,
      color: 'rgba(244,243,239,0.4)',
      marginTop: 32
    }
  }, "\xA9 2026 IVORY MEDIA \xB7 IVORYMEDIA.COM.AU"));
}
Object.assign(window, {
  Nav,
  Hero,
  Brands,
  Services,
  Industries,
  WhyUs,
  Work,
  Process,
  StatsBand,
  Testimonials,
  Insights,
  FAQ,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Card = __ds_scope.Card;

__ds_ns.QuoteBlock = __ds_scope.QuoteBlock;

__ds_ns.ClipText = __ds_scope.ClipText;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Logo = __ds_scope.Logo;

})();
