# Ivory Media — Design System

The **Kelly-green editorial refresh** for **Ivory Media**, a Sydney founder-led video
studio making story-led video and digital content for the industries that grow and
build Australia — agriculture, manufacturing and education. Video-led, warm,
confident. Ivory + near-black carry every layout; one Kelly-green moment per view.

Site: ivorymedia.com.au · © 2026.

## Sources this system was built from

- `uploads/Ivory Media Branding Refresh.zip` — the brand-refresh export (extracted to `source/`):
  `colors_and_type.css` (token source of truth), `COLOUR-tokens-handoff.md` (old→new
  hex migration map), `README.md`, `SKILL.md`, `preview/` foundation + component cards,
  and `assets/` logo/mark PNGs.
- **Reference project** `Ivory Media Launch Kit` (project `e7bf485b-33ce-450f-9530-3678634582f7`) —
  a full launch kit *consuming* this system: the marketing website, work/services/contact
  pages, case study + article, sales deck, and social/ad/stationery templates. The UI kit
  here is ported from its canonical `Ivory Media Website.dc.html` recreation; the copy bank
  comes from its `brand-notes.md`. You may not have access — values are reproduced here.

Fonts (Host Grotesk, JetBrains Mono) are loaded from Google Fonts — no local binaries. If
you want them self-hosted, send the font files and they'll be swapped to `@font-face`.

## Index

- `styles.css` — the entry point consumers link. `@import`s only.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css` (gradients/
  textures/shadows), `fonts.css` (Google Fonts import).
- `components/` — React primitives (see Components below).
- `ui_kits/website/` — the full marketing homepage recreation (`index.html` + `Sections.jsx`).
- `guidelines/` — foundation specimen cards (Colours, Type, Brand, Spacing groups).
- `assets/` — `im-logo-black/ivory.png`, `im-mark-black/ivory.png`.
- `source/` — the original extracted brand export, kept for reference.
- `SKILL.md` — Agent-Skills manifest so this folder drops into Claude Code.

## Components

Built from the source component inventory (buttons, chips/tags, cards, stat blocks,
quote blocks) plus two **intentional additions**:

- **Button** — primary (gradient CTA), solid, secondary (outline), ghost. Sizes + pill.
- **Chip** — dark (default tag), gradient (hero label only), bone, outline, meta.
- **Eyebrow** *(intentional addition)* — the uppercase mono meta label used everywhere;
  worth a primitive because it's the system's connective tissue.
- **Logo** *(intentional addition)* — wraps the four logo/mark PNGs with tone rules;
  encodes "never recolour, ivory-on-dark / black-on-light-or-green".
- **Card** — light / bone / dark content card (dark carries a corner mark watermark).
- **StatBlock** — big-number proof block (bone / dark / gradient-with-hatch).
- **QuoteBlock** + **ClipText** — outcome-carrying testimonial with the text-clip payoff.

## Brand summary

| Element | Value |
|---|---|
| Accent — light | Kelly `#6FCF4E` |
| Accent — mid | `#3DA82F` (solid fills) |
| Accent — deep (green text on ivory, AA) | `#237818` |
| Light background | Ivory `#F4F3EF` (never pure white) |
| Dark background | Near-black `#0E1216` |
| Warm neutral | Bone `#E6E3D9` |
| Headline + body | Host Grotesk (700 headlines, sentence case) |
| Meta / eyebrow | JetBrains Mono (uppercase, 0.16em) |

## CONTENT FUNDAMENTALS

**Voice:** warm, direct, sharp, human. Australian English. The studio speaks as a
confident peer who's been "on the floor and in the field", not a hype agency.

- **Person:** "we" for the studio, "you/your" for the client ("Bringing the magic to
  **your** brand"). First person plural, second person singular address.
- **Casing:** headlines are **sentence case**, always ("Let's make something worth
  watching", "One team, every platform"). Only mono eyebrows/meta are UPPERCASE.
- **Contractions on:** "Let's", "haven't", "we'll". Conversational, never stiff.
- **No em dashes as decoration** in body voice — but the system does use a spaced hyphen
  for asides. Keep punctuation calm.
- **Proof in numbers, not adjectives:** "476 leads in 8 weeks", "30% YoY growth", "60+
  5-star reviews", "$6.65 CPL". Testimonials earn their place only if they carry a
  specific outcome ("the content finally sounds like us").
- **Earned, specific CTAs:** "Start a project", "See our work", "Read the case study",
  "Book a call". Never "Learn more", "Submit", "Click here".
- **Tagline register:** short, filmic, a little playful — "Work worth watching",
  "Bringing the magic to your brand", "Measured in results, not likes", eyebrow
  "Ready to unleash the magic?"
- **No emoji. Ever.** Meaning is carried by type, the mono eyebrow, and the green pop.

## VISUAL FOUNDATIONS

- **Colour — the 80/20 rule.** One Kelly-green moment per layout; ivory and near-black do
  everything else. Kelly is bright enough that **near-black `#0E1216` text sits on green**
  (this reverses the earlier ivory-on-green rule). Green *text* on ivory must be Deep
  `#237818` — mid `#3DA82F` fails AA for small text. Imagery reads warm and natural
  (bone/ivory placeholders, real film stills), never cool or blue.
- **Type.** Host Grotesk for headlines (700, sentence case, tracking -0.03 to -0.045em,
  line-height 0.95–1.0 — headlines get bigger than you think) and body (400/500, 1.6).
  JetBrains Mono for eyebrows, indices, URLs, section markers (uppercase, 0.14–0.20em).
  The two roles **never** mix.
- **Backgrounds & textures.** Ivory or near-black flats. Signature textures: a **dot grid**
  (`radial-gradient`, 20px on ivory / 24px on black), a **45° hatch** over green panels
  (`rgba(14,18,22,0.055)`), and a **striped photo/film placeholder** (`#E6E3D9`/`#DDD9CD`
  45° stripes + mono caption) that the user swaps for real photography. The **mark** appears
  as a corner **watermark at 7–12% opacity**, bleeding off an edge.
- **Gradients (rationed).** Button `135°` `#6FCF4E→#3DA82F`; panel `155°` `#6FCF4E→#3DA82F
  60%→#237818` (+ hatch); text-clip `120°` `#6FCF4E→#55BC3E→#3DA82F` — text-clip never ends
  in deep on dark. All green surfaces carry near-black text.
- **Corner radii.** 9px buttons · 12px chips/small cards · 18px cards/panels · 999px pills.
- **Cards.** Light = ivory + `1px rgba(20,20,20,0.12)` border, no heavy shadow; bone = warm
  fill, no border; dark = near-black with a faint corner mark. Card shadow when used is soft
  and wide: `0 2px 40px rgba(0,0,0,0.10)`. Radius 18.
- **Elevation / transparency.** Mostly flat. The sticky nav uses `rgba(244,243,239,0.92)` +
  `backdrop-filter: blur(8px)`. Blur is reserved for that floating nav — not decorative.
- **Borders.** Hairline: `rgba(20,20,20,0.12)` on light, `rgba(244,243,239,0.14)` on dark.
  Section dividers are single 1px hairlines. Process steps use a 2px green top-border that
  darkens down the ramp (light → deep).
- **Motion & states.** Restrained. Primary button hover: `brightness(1.05)`, lift
  `translateY(-1px)`, and a green glow `0 8px 24px rgba(61,168,47,0.30)`. Secondary hover
  inverts to near-black fill. No bounce, no long easings — quick `.15s` transitions, fades
  over movement.

## ICONOGRAPHY

The brand is **type-led and largely icon-free** — meaning is carried by the mono eyebrow,
big numbers, the green pop, and the striped media placeholders. Where marks appear:

- **Logo & monogram** are the primary graphic device (`assets/im-*.png`). The square "IM/W"
  mark doubles as a corner watermark. Never recolour or stretch it.
- **Stars** for ratings are the literal glyph `★` (`#237818` / `#3DA82F`), not an icon set.
- **Play affordance** on the showreel is a CSS triangle inside a near-black disc — geometry,
  not an icon font.
- **No emoji, no Unicode symbol soup.** The only recurring non-letter glyphs are `★`, `→`
  (in CTAs/links), `+` (FAQ toggles), and the mono middot `·` in meta strings.

No icon font ships with the brand. If a build genuinely needs UI glyphs (e.g. social icons
in a footer), use a neutral line set — **Lucide** at ~1.75px stroke is the closest match to
the type weight — and keep it monochrome (ink or slate). Flag any icon use for review.
