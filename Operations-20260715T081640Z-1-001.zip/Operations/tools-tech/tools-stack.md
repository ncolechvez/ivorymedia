# Tools Stack

## Active daily use

| Tool | Role |
|---|---|
| Shade | Production drive ecosystem. ALL working files, footage, review and delivery live here. |
| ClickUp | Sole project management tool |
| GoHighLevel | CRM, leads, funnels (owned account) |
| Fathom | Meeting recordings and transcripts |
| Slack | Team comms |
| WhatsApp | Quick comms |
| Claude (Code + Desktop + web) | AI operating layer |
| Trigger.dev | Cloud automation |
| Vercel | Website hosting (ivorymedia.com.au, Astro) |
| Descript, Adobe suite, DaVinci Resolve | Edit and post tools |
| Obsidian (occasional), Notion (light) | Notes |

## Retired (do not use or reference as current)

- Plutio (replaced by ClickUp)
- WordPress site (replaced by Astro on Vercel, July 2026)

## Rules

- No credentials, API keys or logins in this workspace, ever
- If a tool decision changes, update this file and tell Steven
