# Team

Ivory Media is a 1-person business. Steven Makari is the only full-timer. Contractors are engaged per job, with AI agents as the operating layer.

## Founder

- **Steven Makari**: founder, sole operator. Strategy, sales, client relationships, direction on every job.

## Videographers (active)

- Mikey Matthews
- Anthony Gibbs (also edits)
- Aidan Hardwick
- Chris Whiting

Always looking for additional camera operators.

## Editors

- Anthony Gibbs (per job)
- Philippines-based full-time editor (recruitment finalising, July 2026)

## Operations / admin

- **Nicole Chavez**: VA, content and admin ops. Owns Ivory's organic posting cadence and the Cosmetic Connection content calendar.
- **Alvin Vincent Lapating Dy**: Philippines-based, editing support.

## ClickUp access model

- Nicole and Alvin: members (see public spaces)
- Anthony: guest, chat only; Steven shares projects ad hoc
- Guests never see public spaces, only explicitly shared items

## Rules

- Use client names, not project codenames, in team-facing comms
- Contractor rates and financial terms are handled by Steven directly and do not live in this workspace
