# Production Workflow

## Principle

**Everything lives in Shade.** Project files, working files, review links, final delivery. Every contractor, globally, works in the one ecosystem. No footage or working files scattered across personal drives.

## Shoot to delivered video

1. Camera operator shoots
2. Footage uploaded to Shade (or sent via drive if faster for the job, then into Shade)
3. Editor briefed in
4. Editor builds V1
5. V1 shared with the client via Shade
6. Client leaves comments and feedback directly in Shade
7. Editor revises (V2, V3, V4) until client sign-off
8. Final delivery: download links provided within Shade

## OCS delivery cycle (6 months)

1. Client pays the $1,500 deposit (credited to first invoice)
2. Strategy call within the week
3. Build the 6-month strategy: content pillars, filming plan, posting cadence, organic growth plan
4. Strategy presentation with 90-day forecast. Go / no-go. If they walk, the plan is theirs to keep.
5. Map content topics, scripts and shooting schedule. Lock the shoot date.
6. Shoot day: one session produces roughly 3 months of posting content
7. Monthly: track per-video performance, report to the client, note winners and losers
8. Round 2 (months 4-6) adjusted from Round 1 learnings
9. Loop repeats each engagement

## File naming

Naming conventions for camera operators and editors are being mapped out. Once locked they live in `Production/naming-conventions/`. Until then, ask Steven rather than inventing a scheme.
