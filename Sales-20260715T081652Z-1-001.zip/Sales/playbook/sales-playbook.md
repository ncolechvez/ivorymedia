# Sales Playbook: Organic Content System

## The call

- **30 minutes** (changed from 45, July 2026)
- Drop heavy value upfront, no hiding
- Goal: the lead walks away with a roadmap they could take and run with, even if they don't buy

## Close mechanics

1. Walk through the offer.
2. Present the $1,500 strategy deposit, credited to the first invoice. Guarantee: **"Love the Strategy or Walk."** If they walk, the plan is theirs to keep.
3. Position: small first commitment, full strategy delivered, decide on the full engagement after seeing the strategy (with its 90-day forecast).
4. Capacity framing: 5 new clients per month.

**Lesson that shaped this:** don't try to close the full $15K on the call. Lower the first-yes threshold, build trust, then expand.

## Selling style

Per `Context/brand-voice.md`: rapport first, transparent pricing stated plainly, value framed around client outcomes, soft close. Never hard-sell language, never apologise for price, one gentle follow-up nudge then wait.

## Objections battle card

| Objection | Response |
|---|---|
| "We've tried content before and it didn't work" | You had content without a system. We build the system. |
| "That's a lot of money" | You're spending more than that on ads with diminishing returns. This compounds and brings ad costs down. |
| "We don't have time to film every month" | One session covers a quarter. We handle everything else. |
| "How do we know it'll work for our industry?" | 700+ projects across higher ed, industrial, healthcare, finance, government, professional services. The strategy is tailored. |
| "What if we don't like the strategy?" | Love the Strategy or Walk. If you walk, the plan is yours to keep. Zero risk. |
| "Can't we hire someone in-house?" | You'd need 3-4 people to match what we deliver. We're cheaper than one hire. |
| "We got burnt by the last agency/freelancer" | That's why the guarantee exists. Plus 700+ projects since 2016. We're not freelancers with a camera. |
| "I need approval from my director" | The strategy presentation is built to be taken up the chain. |

## Disqualify (let them walk)

- Too early-stage (solo, no team, watching every dollar)
- Not ready for 6 months
- Vendor trust scars too deep
- Stuck in internal procurement

## After the deposit

1. Strategy call within the week
2. Build the 6-month strategy (pillars, filming plan, posting cadence, organic growth plan)
3. Strategy presentation with 90-day forecast. Client decides go / no-go.
4. Go: deposit credited to the first invoice, delivery begins (see `Production/sops/production-workflow.md`)

## Rules

- All proposals and client-facing sales material are drafts until Steven approves
- ICP and pain points live in `Context/icp-profile.md`, offer detail in `Context/about-agency.md`
