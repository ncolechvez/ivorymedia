# About Ivory Media

## The agency

Ivory Media is a Sydney-based video production and growth agency, running since 2016. We help established businesses build organic content systems that reduce ad costs, build their brand, and drive leads. Founder-led (Steven Makari), with a trusted contractor crew per job and AI as the operating layer. 700+ projects delivered, 95% referral rate.

- **Location:** 30/66 Chandos St, St Leonards, NSW (AEST)
- **Website:** www.ivorymedia.com.au
- **Email:** steven@ivorymedia.com.au
- **Phone:** (02) 7252 3612

## Brand positioning

Growth partner for businesses that build things. Tagline: **"Serious growth for businesses that do serious work."**

Three engines that feed each other:
- **Content Engine** (get seen)
- **Client Engine** (get clients)
- **AI Engine** (get time back)

Site nav: Content, Advertising, AI & Automation.

## Services: the live offer

**In transition (14 Jul 2026).** Two models exist side by side right now. Use judgement on which to lead with until Steven locks this down, and flag it in any deliverable where it matters.

### The three engines (current live site positioning)

The site (ivorymedia.com.au) no longer markets "OCS" by name. It sells three modular products that feed each other:

| Engine | Promise | What's in it |
|---|---|---|
| **Content Engine™** | Get seen | Quarterly shoots (site copy says "monthly", that's stale, confirmed quarterly is correct), Reels & Shorts, LinkedIn & YouTube, photography |
| **Client Engine™** | Get clients | Meta & Google ads, landing pages, email & CRM |
| **AI Engine™** | Get time back | Automation, lead routing, custom AI agents |

Clients can run one or all three. No published rate card: pricing is scoped per client after a "growth call," proposal follows.

### OCS structure (previous entry offer, may still be in use)

**Organic Content System (OCS)** was documented as the sole sales focus as of the last OS build (14 Jul 2026 AM).

One sentence: "A done-for-you organic content system where we handle strategy, scripting, filming, editing, and posting so you stop overpaying for ads and start building a brand that generates leads on its own."

| Component | Detail |
|---|---|
| Front-end entry | $1,500 AUD strategy deposit, credited to the first invoice (not refundable) |
| Full engagement | $15,000 AUD per quarter ($30,000 over 6 months) |
| Commitment | No lock-in. Can leave after 3 months. |
| Payment options | $30K upfront OR $16.5K per quarter |
| Capacity | 5 new clients per month |

**What the $1,500 buys:** a discovery session, a full 6-month content strategy (pillars, filming plan, posting cadence, organic growth plan), a strategy presentation with a 90-day forecast. **Guarantee: "Love the Strategy or Walk."** If they walk, the plan is theirs to keep.

**What the $15K/quarter buys:** 1 filming session per quarter (2 across 6 months), full strategy, scripting, filming, editing, posting and management, a content mix of video (Reels / short-form), carousels and statics per strategy, profile optimisation, and a Q1-learnings-feed-Q2 optimisation loop.

**Not included on the front end (back-end upsells):** Meta / Google ad management, funnel builds and landing pages, email marketing.

> **Resolved (14 Jul 2026):** cadence is quarterly, per OCS. The site's "monthly shoots" copy on the Content Engine page is stale and needs fixing on the live site separately (not an OS task). Do not quote monthly cadence.

> Note: some older ad copy still says "refundable deposit". OCS pages and the sales deck say "credited". Credited is correct; flag stale copy when you see it.

> **Resolved (14 Jul 2026):** the techgrow.com.au "Website homepage redesign" job is a one-off favour/exception, not a documented service. Not part of the standard offer, don't reference it in proposals or content.

## Parked and retired offers (do not sell or reference as current)

- **The Launch Sprint** (brand + website + Meta ads live in 10 business days): built and ready, parked until OCS is validated. Do not sell unless Steven reactivates it.
- Retired: 2-Hour Content System, 7-Day Client Engine, Strategy/Story/Scale retainer, AI Automations sales kit. If any document refers to these as current, it is stale.

## How we work

- **All working files live in Shade.** Footage, project files, review links, final delivery. One ecosystem for every contractor.
- **ClickUp is the sole PM tool.** Fathom records meetings. GoHighLevel is the CRM.
- **Quality bar:** premium and polished, but not over-polished. 80 to 90% is shippable. Cover the basics, ship, iterate.
- **Anti-patterns (never do these):** no em dashes in anything. No generic AI phrasing. No corporate jargon. Never send anything client-facing without Steven's approval; draft only.

## Team

Steven Makari (founder, sole full-timer) plus a contractor crew per job. See `Operations/team/team.md` for roles.

## Proof points

- 700+ projects delivered since 2016, 95% referral rate
- Marketing headline stats: $10M+ revenue influenced, 5,000+ videos, 10M+ views, 200+ clients across Australia
- **UNSW Gateway Program:** 4% increase in program enrolment attributed to the video campaign; led to ongoing work across multiple faculties. Site adds: hit 100% of enrolment target early.
- **CNH (Case IH / New Holland):** 4-year APAC partnership, 35% YoY social engagement growth, one reel at 750K views, millions in machinery sales influenced
- **NSW Department of Education, National Skills Week:** 50K+ views, 28% lift in program page traffic
- **Blackwoods:** two campaign videos at 500K+ views each, direct uplift in sales
- **Obex:** brand package, shoot to delivery in 2 weeks, 1 hero video + 3 social videos + full image library
- Client quote: "They did an excellent job with the branding and marketing design of my business... produced quality content that really makes me stand out from my competitors." (Alex Ainsworth, Vance Finance)
- Trusted by (per live site, checked 14 Jul 2026): UNSW, NSW Department of Education, Blackwoods, CNH Industrial, City of Sydney, Bullivants, Prosafe Protective Safety, SGCH, Fujifilm, HiBob, UpGuard, SaCSA, Obex
- Also in the OS but not currently on the public trusted-by list: Premium Strata, Pepsi, Cosmetic Connection, Princeton Health (active/recent relationships per Clients folder and sent mail)

## What makes us different

Everyone sells "3 months of content in a day". Ivory sells an organic content **system**, not content: strategy through optimisation, one filming session per quarter, white-glove, broadcast-grade, built around reducing paid ad dependence.

The big reveal: "Most businesses think they need more ads. They don't. They need an organic system that makes their ads work harder." Ad clicks that land on a dead profile bounce. Ad clicks that land on a stacked profile convert. The organic system doesn't replace ads, it supercharges them.
