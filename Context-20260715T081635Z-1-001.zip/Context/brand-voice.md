# Brand Voice: Ivory Media

## Tone

Professional with a bit of humour. Real, clean, fresh, on point. Fun but classy. It reads like Steven at a professional level: warm, direct, confident from experience, never corporate.

## How we sound

- **Warm first, business second.** Every email opens with a human connection point, never cold.
- **Direct without being blunt.** Lead with the answer, the update, or the action. Context after.
- **Short and scannable.** Short sentences, generous line breaks, one thought per line. No walls of text.
- **Confident, not arrogant.** Prices stated plainly, no hedging, no apologising. Expertise shown through specifics, not superlatives.
- **Conversational.** Contractions always: I'll, we've, it's, don't.

## Language preferences

- Australian English (organise, realise, colour, centre)
- No em dashes or en dashes, ever. Use commas, colons, or parentheses.
- Emojis rare (roughly one per 20 emails). An occasional ":)" is fine.
- Never "Dear", "Kind regards", "Best", "Cheers", or "Please find enclosed"
- Client emails sign off "Thanks," then "Steve" on the next line

## Words and phrases we use

- "Hey [Name]," / "Morning [Name],"
- "Sounds good" / "All good" / "No worries" / "Not a problem at all"
- "I'll get that over to you [timeframe]"
- "Let me know if you have any questions"
- "I'll keep you posted"
- "Legend, thanks [Name]" / "Perfect, thanks [Name]"
- "Happy to [action]" / "Appreciate you [action]"
- "Look forward to [action]"
- "mate" occasionally, with closer contacts
- "awesome", genuinely

## Words and phrases to avoid

- Hard-sell language: "limited time", "act now", "don't miss out"
- Superlatives: "best in class", "world-class", "leading", "cutting-edge"
- Corporate filler: "I hope this finds you well", "just circling back", "touching base", "per my last email"
- AI-slop phrasing: "delve", "leverage", "unlock", "elevate", "seamless", "game-changer", "in today's fast-paced world"
- Over-apologising. One brief acknowledgment, then the fix and a specific new timeline.

## Voice in action

**Delivering work:** "Hey Gavin, both comments have been addressed. If you're happy with this one, it's ready for you to download directly from the platform."

**Handling a delay:** "Just letting you know that I'm still working through this and will need until Monday to tidy everything up and get it over to you."

**Selling:** rapport first, options presented clearly with transparent pricing (2-3 tiers, what's included then the price), value framed around what the client gets, soft close ("Once you've had a chance to review, happy to jump on a call to work through the direction that makes the most sense").

**Directing contractors:** clear, brief, collaborative. "Can we prioritise this one for this week please?" not commands. Real example: "Hey Chris, when you have a moment, can you please sort out the LTL project files for me. Please put everything here. I'm going to sort your invoice out today but really need the files mentioned."

**Re-engaging an old contact:** warm, personal before business. "Hey mate, hope you're well. It's been way too long, and yes, a drink is definitely overdue. Let's schedule something in."

**Quoting on a real brief:** acknowledge the brief, ask sharp clarifying questions before pricing. "Thanks for sending this through, I love the concept and the brief is really well put together. Before I get a quote across, a few quick questions: how many shoot days are you envisioning?"

## Signature block

Confirmed from sent mail, used consistently:

```
Thanks,
Steve

[photo]
Steven Makari
Director
0423 418 696
Suite 30, 66 Chandos Street, St Leonards
ivorymedia.com.au
```

Casual internal/contractor emails sometimes drop straight to the photo signature block with no "Thanks, Steve" line above it.
