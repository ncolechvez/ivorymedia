# Ideal Client Profile: Ivory Media

## Who they are

### Primary decision-maker (the buyer)

- Founders, CEOs, owners of established service-based businesses
- 3+ staff, an office, existing clients
- 3-10+ years in business, $500K to $5M+ revenue
- Already spending money on ads
- Controls the budget

### Secondary day-to-day contact (the champion)

- Marketing, Communications or Digital Engagement Managers inside medium-to-large organisations (50 to 10,000+ employees)
- No in-house video production
- Coordinate between internal stakeholders and external vendors
- Not the budget holder; must justify spend up the chain
- Their reputation is tied to what Ivory delivers

### Industries (broad, not niching)

Professional services, medical/health, finance, legal, consulting, education, corporate, government, B2B. Existing base spans higher education (UNSW), industrial (Blackwoods, Bullivants), agriculture (CNH), healthcare (MSD, Princeton Health), government (Dept of Education, SaCSA), HR tech, strata. Live site (checked 14 Jul 2026) frames the core sectors more narrowly as agriculture, manufacturing, industrial, education, corporate, government, medical.

### Active segment: private colleges and RTOs (as of 14 Jul 2026 outreach)

A live cold-outreach campaign is running to marketing/admissions contacts at private colleges, RTOs and international education providers: Kaplan Business School, AIB, AIPT, Collarts, EIT, Greenwich College, Stanley College, College for Adult Learning, Albright Institute, OES. Distinct from the UNSW-style university relationship, these are typically admissions or marketing managers who recruit international or working-adult students and decide largely before a prospect sets foot on campus.

Pitch pattern used: name the story they're sitting on (student outcomes, graduate stories, campus experience, transformation stories) and point out how little of it is actually shown. Subject lines follow "[institution]'s [story], barely/rarely shown."

> **Status (14 Jul 2026):** active experiment, not yet a core segment. Keep noted here but don't fold into the main buyer/champion profile until results are in. Revisit once the campaign has enough replies to judge.

### Common thread

They know they need organic content but don't have the time, team, or system to produce it consistently. They want a vendor who takes ownership.

## What they're dealing with (their language)

**Worst-day narrative:** back-to-back meetings, 40 unread emails, content keeps getting pushed. Instagram dead for weeks. Competitors with less experience are pumping out content. They know organic would bring ad costs down but they can't get it consistent. Burnt by past vendors, gun-shy about trusting another one.

**Top fears:**
- Ad costs climbing, fully dependent on paid
- No organic engine catching people and building trust
- Burnt budget with diminishing returns
- Vendor trust scars (offshore editors, overcomplicating freelancers, generic social managers)
- Bringing a bad recommendation up the chain again
- Competitors compounding their organic advantage

**What they've tried that failed:** offshore editing (embarrassing quality), overcomplicating freelancers (more admin, scope creep), generic social media managers (wrong tone, no traction), in-house attempts (die after a few weeks), one-off brand videos (sit on a drive), self-filming on iPhone (inconsistent, no strategy), more ad spend (diminishing returns), referrals only (unpredictable).

## Trigger moments

- Ad costs have crept up again and the numbers no longer stack
- A competitor's content keeps showing up in their feed
- A new marketing manager inherits a dead social presence and needs a win
- The last vendor or freelancer just failed and they need someone who takes ownership
- Internal "we should be doing content" pressure finally reaches the budget holder

## Who they're not (anti-ICP / walk-away list)

- Too early-stage: solo, no team, watching every dollar
- Not ready for a 6-month engagement
- Vendor trust scars too deep to move
- Stuck in internal procurement with no path through

> Objection handling lives in `Sales/playbook/sales-playbook.md`.

> These pain points and desires are v1, not locked. Steven is open to interrogating and refining them.
